
/** Name: Hamad Nasir
 *  Roll No.: 120312
 *  Section: BSCS-6C
 *  Advanced Programming Assignment:2
 **/

package com.hamadnasir.lab_hibernate;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;
import java.sql.*;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import java.io.*; 
import java.net.*; 

public class TCPclient 
{
    public static void main( String[] args )throws Exception
    {
    	//scanner object for taking input
		Scanner input = new Scanner(System.in);
		//objectmapper object for converting object to JSON format
		ObjectMapper mapper = new ObjectMapper();
    	//creating person object
		Person obj = new Person();
    	
    	//a string variable for storing user input
    	String sv;
    	//creating input stream
        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in)); 
        //creating client socket connect to server
        Socket clientSocket = new Socket("10.7.12.251", 6789); 
        //create output stream attached to socket
        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream()); 
        //create input stream attached to socket
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
       
       
        //client side user interface
    	System.out.println("1. Register a person:");
    	System.out.println("2. Search aperson:");
    	System.out.println("3. Delete a person:");
    	System.out.println("4. Update a person:");
    	System.out.println("5. To exit:");
    	//user enters option number
    	System.out.println("Enter the option number:");
    	String option = input.nextLine();
    	
    	//sending the string in option variable to server
    	outToServer.writeBytes(option + '\n');
    
    	//switch cases for functions depending upon user input
    	switch (option) {
    	//for Inserting a person in to database
    	case "1":   	
	    
    	//getting username of the person	
    	System.out.println("Enter username:");
		String username = input.nextLine();	
		
		//sending the username to server for checking whether duplicate or not
		outToServer.writeBytes(username + '\n');
		
        //getting remaining person attributes
		System.out.println("Enter first name:");
		String fname = input.nextLine();
		System.out.println("Enter last name:");
		String lname = input.nextLine();
		System.out.println("Enter password:");
		String password = input.nextLine();
		System.out.println("Enter access level:");
		String alevel = input.nextLine();
		System.out.println("Enter mobile:");
		String mobile = input.nextLine();
		
		
		//setting the input attributes to the person object	
		obj.setUsername(username);
		obj.setFirstName(fname);
		obj.setLastName(lname);
		obj.setPassword(password);
		obj.setAccessLevel(alevel);
		obj.setmobile(mobile);
    	
		
		  // Object to JSON Conversion
    	try {
						
			//Convert object to JSON string
			String js = mapper.writeValueAsString(obj);
			//printing the JSON object on client side
			System.out.println("JSON object sent to server: \n" + js);
    		//sending the JSON object to server as string
			outToServer.writeBytes(js + '\n');
			//getting the confirmation response of server whether stored in database or not
			sv = inFromServer.readLine(); 
			//printing the response of server
	        System.out.println("From Server: \n" + sv);
			
			
		//catch blocks for capturing exceptions if any  	
			
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	//closing the socket in the end
		clientSocket.close();
     break;
         
   //for Searching a person from database
    	case "2":	
        
    	//getting the username of person to be searched in database
    	System.out.println("Search the username:");
		String name = input.nextLine();
		//sending the username to server 
		outToServer.writeBytes(name + '\n');
		//getting response of server
		sv = inFromServer.readLine();
		//if username found in database its object will be shown and if not found then error response will be shown
        System.out.println("From Server: \n" + sv); 
        //closing the socket
        clientSocket.close();
    break;

   //for deleting a person from database
    	case "3":
    		
	    //getting the username which is to be deleted from database 
		System.out.println("Enter username to delete:");
		String name1 = input.nextLine();
		//sending the input username t server
		outToServer.writeBytes(name1 + '\n');
		//getting the response from server
		sv = inFromServer.readLine(); 
		//if username found then it will be deleted & confirmation response otherwise error response shown
        System.out.println("From Server: \n" + sv);
		//closing the socket
    	clientSocket.close();	
    	break;	
    
    //for updating a person from database
    	case "4":
		
    	//enter the username whose record is to be updated	
		System.out.println("Enter username to update records:");
		String username1 = input.nextLine();
		//sending the username to server for checking whether username stored in database or not
		outToServer.writeBytes(username1 + '\n');
		
        //getting the updated attributes and sending them to server one by one
    	System.out.println("Enter new first name:");
		String fname1 = input.nextLine();
		outToServer.writeBytes(fname1 + '\n');
		System.out.println("Enter new last name:");
		String lname1 = input.nextLine();
		outToServer.writeBytes(lname1 + '\n');
		System.out.println("Enter new password:");
		String password1 = input.nextLine();
		outToServer.writeBytes(password1 + '\n');
		System.out.println("Enter new access level:");
		String alevel1 = input.nextLine();
		outToServer.writeBytes(alevel1 + '\n');
		System.out.println("Enter new mobile:");
		String mobile1 = input.nextLine();
		outToServer.writeBytes(mobile1 + '\n');
		
		
		//getting the response from the server
		sv = inFromServer.readLine(); 
		//if the username was found earlier then confirmation response otherwise error response  
        System.out.println("From Server: \n" + sv);
		//closing the socket
    	clientSocket.close();
       break;
       
       //for handling invalid input
       default:
    	   //getting the response from the server
   		   sv = inFromServer.readLine();   
           System.out.println("From Server: \n" + sv);
   		   //closing the socket
       	   clientSocket.close();
       
    	}//switch block closing	
   
    }//main closing
    
}//class closing
