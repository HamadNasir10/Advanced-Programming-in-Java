

/** Name: Hamad Nasir
 *  Roll No.: 120312
 *  Section: BSCS-6C
 *  Advanced Programming Assignment:2
 **/

package com.hamadnasir.lab_hibernate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Person {
	
	//setting Username as primary key
	@Id
	private String Username;
	private String FirstName;
	private String LastName;
	private String Password;
	private String AccessLevel;
	private String mobile;
	
   //setter and getter methods for attributes
	public String getUsername() {
		return this.Username;
		
	}
	
	public String getFirstName() {
		return this.FirstName;
		
	}
	public String getLastName() {
		return this.LastName;
		
	}
	

    public String getPassword() {
	   return this.Password;
	
    }
	
    public String getAccessLevel() {
		return this.AccessLevel;
		
	}
	
	public String getmobile() {
		return this.mobile;
		
	}
	
	public void setUsername(String Username) {
		this.Username = Username;
		
	}
	
	public void setFirstName(String FirstName) {
		this.FirstName = FirstName;
		
	}
	public void setLastName(String LastName) {
		this.LastName = LastName;
		
	}
	public void setPassword(String Password) {
		this.Password = Password;
		
	}
	
	public void setAccessLevel(String AccessLevel) {
		this.AccessLevel = AccessLevel;
		
	}
	public void setmobile(String mobile) {
		this.mobile = mobile;
		
	}
   
	//to string method for printing an object of person
	@Override
	public String toString() {
		return "Person [Username=" + Username + ", FirstName=" + FirstName + ", LastName=" + LastName + ", Password="
				+ Password + ", AccessLevel=" + AccessLevel + ", mobile=" + mobile + "]";
	}
	
}