
/** Name: Hamad Nasir
 *  Roll No.: 120312
 *  Section: BSCS-6C
 *  Advanced Programming Assignment:2
 **/

package com.hamadnasir.lab_hibernate;
import java.io.*; 
import java.net.*; 
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;
import java.sql.*;
import javax.transaction.Transaction;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.service.jdbc.connections.spi.DataSourceBasedMultiTenantConnectionProviderImpl;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;

public class TCPserver {
	public static void main(String argv[]) throws Exception 
    { 
		   //contains properties required for session factory
		    Configuration con = new Configuration().configure().addAnnotatedClass(Person.class); 		
			//ccontains registry of services
		    ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
			//used for object relational mapping
			SessionFactory sf = con.buildSessionFactory(reg);
			//Session API for connecting hibernate and java application
			Session session = sf.openSession();
			//handle transactions associated with session
			org.hibernate.Transaction tx = session.beginTransaction();
			
			ObjectMapper mapper = new ObjectMapper();
	    	Person obj = new Person();	  
	        //string variable for storing strings from client
	         String s1,option;
	 
	  //Create welcoming socket at port 6789
      ServerSocket welcomeSocket = new ServerSocket(6789); 
      
      System.out.println("Server is waiting for client.......");
      while(true) { 
            
    	    //Wait, on welcoming socket for contact by client
            Socket connectionSocket = welcomeSocket.accept(); 
           //Create input stream, attached to socket
           BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())); 
           //Create output stream, sttatched to socket
           DataOutputStream  outToClient = new DataOutputStream(connectionSocket.getOutputStream());
           
           //reading the option selected by user at client
           option = inFromClient.readLine();
           System.out.println("From Client Selected Option: \n" + option);
          
           
           //according to option selected server will provide a particular functionality
           switch(option) {
         
           //if the user has selected to register a person
           case "1":
           //reading the input username
           s1 = inFromClient.readLine();
           //getting the object of that username from database
           obj = (Person) session.get(Person.class,s1);
           //if object of that username is not found
           if(obj == null) {
        	     //get the JSON string sent by client, store it in s2
                 String s2 = inFromClient.readLine();
                 //Convert JSON string to object p1
                 Person p1 = mapper.readValue(s2, Person.class);
                 //store the p1 object to the database
                 session.save(p1);
                 String s3 = "Success: { "+s1+" } Successfully Registered!" + '\n';
                 //send the confirmation response to client
                 outToClient.writeBytes(s3); 
          
           }else { //if object of that username is found
        	     //send the error response to client
                 String s ="Error: Duplicate Username { "+s1+" }" + '\n';
                 outToClient.writeBytes(s);
          } 
           //commit the transaction
         tx.commit(); 	
         break;
        	
       //if the user has selected to search a person
           case "2":
        //reading the input username
        s1 = inFromClient.readLine();
        //getting the object of that username from database 
        obj = (Person) session.get(Person.class,s1);
        //if object of that username is not found
        if(obj == null) {
        	     //send the error message to client
                String s ="Error: User { "+s1+" } Not Found!" + '\n';
                outToClient.writeBytes(s); 
        }else {
        	    //if the object of that username is found, convert it to string 
                String s = obj.toString() + '\n';
                //sent the object string to client
                outToClient.writeBytes(s); 
        } 
        //commit the transaction
        tx.commit(); 
        break;
 
        //if the user has selected to delete a person
           case "3":
           
       //reading the input username  
       s1 = inFromClient.readLine(); 
       //getting the object of that username from database 
       obj = (Person) session.get(Person.class,s1);
      //if object of that username is not found
      if(obj == null) {
    	       //send the error message to client
               String s ="Error: User { "+s1+" } Not Found!" + '\n';
               outToClient.writeBytes(s); 
      }else {
    	       //if the object of that username is found, delete that object 
               obj.setUsername(s1);
               session.delete(obj);
               //send the confirmation message to the client
               String s = "Success: { "+s1+" } Successfully Deleted!" + '\n';
               outToClient.writeBytes(s); 
      }    
      //commit the transaction
      tx.commit();  
      break;
 
          //if the user has selected to update a person
           case "4":

     //reading the input username 
     s1 = inFromClient.readLine();
     //getting the object of that username from database
     obj = (Person) session.get(Person.class,s1);
     //if object of that username is not found
     if(obj == null) {
    	      //send the error message to client
              String s ="Error: User { "+s1+" } Not Found!" + '\n';
              outToClient.writeBytes(s); 
     
     }else {  //if the object of that username is found, get the update attributes input by user at client
              String s10 = inFromClient.readLine();
              String s11 = inFromClient.readLine();
              String s12 = inFromClient.readLine();
              String s13 = inFromClient.readLine();
              String s14 = inFromClient.readLine();
             
              //execute hibernate query to update records and assign new attributes to that username
              Query q = session.createQuery("UPDATE Person SET FirstName =:fname1, LastName =:lname1, Password =:password1, AccessLevel =:alevel1, mobile =:mobile   WHERE Username =:username1 ");
              q.setParameter("fname1", s10);
              q.setParameter("lname1", s11);
              q.setParameter("password1", s12);
              q.setParameter("alevel1", s13);
              q.setParameter("mobile", s14);
              q.setParameter("username1", s1);
              q.executeUpdate();
 
              //send the confirmation message back to client
              String s ="Success: { "+s1+" } Successfully Updated!" + '\n';
              outToClient.writeBytes(s);
     }
     //commit the tranaction
     tx.commit(); 
     break;
      
           default:
    
    	//send the confirmation message back to client
         String s ="Invalid Input!" + '\n';
         outToClient.writeBytes(s);
    	 
    	 
           } //switch block closing     
      } //while loop closing
   } //main closing
}//class closing
