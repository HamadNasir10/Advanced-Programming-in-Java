Name: Hamad Nasir
Roll No: 120312
Assignment 3

Objective:
                  The goal of the assignment was to develop a dropwizerd based REST API which store a person data using rest API and provide a user interface using swagger. The user can register, update and delete a person. The person database will be mantained on MYSQL, the user will interact swagger interface to see the results of the above mentioned functionalities.