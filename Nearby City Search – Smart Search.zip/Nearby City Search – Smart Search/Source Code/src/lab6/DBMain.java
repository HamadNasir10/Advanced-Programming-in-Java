package lab6;
import java.sql.SQLException;

public class DBMain {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Person obj = new Person();
		DBHandler dbhandler = new DBHandler();
		
		obj.setID(240);
		obj.setname("ibrahim");
		obj.setFname("nasir");
		obj.setorg("s");
		obj.setmobile("0300");
		
		System.out.println("");
		
		
		    dbhandler.checkConnection();
		    
		    if(dbhandler.conn != null ) {
		    dbhandler.insert(obj);
			//dbhandler.update();
			//dbhandler.delete(224);
			
			//dbhandler.get(225);
			dbhandler.conn.close();
			System.out.println("connection closed....");
		    }else {
		    	System.out.println("Connection couldn't created");
		    }

	}
}
