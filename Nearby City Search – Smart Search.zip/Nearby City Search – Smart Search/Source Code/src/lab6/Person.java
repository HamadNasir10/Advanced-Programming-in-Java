package lab6;
public class Person {
	
	private int id;
	private String name;
	private String fatherName;
	private String organization;
	private String mobile;
	

	public int getID() {
		return this.id;
		
	}
	
	public String getname() {
		return this.name;
		
	}
	public String getorg() {
		return this.organization;
		
	}
	public String getFname() {
		return this.fatherName;
		
	}
	public String getmobile() {
		return this.mobile;
		
	}
	
	public void setID(int id) {
		this.id = id;
		
	}
	
	public void setname(String name) {
		this.name = name;
		
	}
	public void setorg(String org) {
		this.organization = org;
		
	}
	public void setFname(String fname) {
		this.fatherName = fname;
		
	}
	
	public void setmobile(String mobile) {
		this.mobile = mobile;
		
	}
}