package lab6;
import java.sql.*;  
import java. util. Scanner;

class Connector{  
	
	Connection method(){	
		Connection con = null;
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}  
		
	singletonClass object = new singletonClass();
	object.get();
	
	
	String userName, password,url;

	
	Scanner in = new Scanner(System. in);
	System.out.println("Enter username: ");
	userName = in.nextLine();
	System.out.println("Enter password: ");
	password = in.nextLine();
	
	boolean usr = new String(userName).equals(object.getUser());
	boolean pswrd = new String(password).equals(object.getpswd());
	
	if(usr && pswrd) {
	userName = object.getUser();
	password = object.getpswd();
	url = object.getURL();
	
	try {
		con = DriverManager.getConnection(url,userName,password);

		System.out.println("Connection establised.."
				+ "\n\n");
		
		return con;	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
	System.out.println("issue in username or password");
	
	}
					}
	return con;
	}
	}