package lab6;
import java.sql.*;  
public class DBHandler {
	
	Connection conn = null;
	Statement stmt = null;
void checkConnection() throws SQLException {
	
	
	Statement stmt = null;
	Connection conn = null;
	Connector obj = new Connector();
	conn = obj.method();
	if(conn != null) {
	stmt = 	conn.createStatement();
	this.conn = conn;
	this.stmt = stmt;
	}else 
	{
		System.out.println("can not create connection...!");
	}
	
	
}	
	
void insert(Person person ) throws SQLException {
		PreparedStatement preparedStatement = null;		
		System.out.println("Inserting records into the table...");
		String sql = "insert into person " +
				"values (?,?,?,?,?);";
		
		preparedStatement = 	conn.prepareStatement(sql);
		preparedStatement.setInt(1, person.getID());
		preparedStatement.setString(2, person.getname());
		preparedStatement.setString(3, person.getFname());
		preparedStatement.setString(4, person.getorg());
		preparedStatement.setString(5, person.getmobile());
		preparedStatement.executeUpdate();
		
		System.out.println("Inserting completed...\n\n");
}


void update() throws SQLException {

	
	System.out.println("updating records into the table...");
	// create the java mysql update prepared statement
	String q2 = "update person set \n" + 
			"name = ?,\n" + 
			"fatherName = ?,\n" + 
			"organization = ?\n" +
			"mobile = ?\n" +
			" where id = ?;";
	 PreparedStatement preparedStmt = conn.prepareStatement(q2);
     
      preparedStmt.setString(1, "Fred");
      preparedStmt.setString(2, "Alvin");
      preparedStmt.setString(3, "newZext");
      preparedStmt.setInt   (4, 100);
      preparedStmt.setInt   (5, 227);
      preparedStmt.executeUpdate();
      System.out.println("updated successfully...!\n");
      
}

	 	
void delete(int pID) throws SQLException {
	

		System.out.println("deleting records into the table...");
		String sql = "delete from person where id = " + pID;
		stmt.executeUpdate(sql);
		System.out.println("deleted successfully..!\n\n");
	}


void get(int pID) throws SQLException {
		System.out.println("displaying records of the table...\n\n");
		
		String query = "select * from person where id = " + pID;
	        ResultSet rs = stmt.executeQuery(query);
	        while (rs.next()) {           
	            System.out.println("id = " + (Integer)rs.getObject(1) 
	            	 + " \nName =  " + rs.getObject(2).toString() + 
	            	 "\nFather Name = " + rs.getObject(3).toString() + 
	            	 "\nOrganization = " + rs.getObject(4).toString() + 
	            	 "\nMobile # " + rs.getObject(5).toString()); 
	            }}}