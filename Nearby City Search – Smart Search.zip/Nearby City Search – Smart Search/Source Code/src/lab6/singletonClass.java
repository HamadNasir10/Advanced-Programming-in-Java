package lab6;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class singletonClass {

	private String url;
	private String user;
	private String pswd;
	
	 singletonClass() {}
	
	 String getURL() {
		
		
		return this.url;
	}
	 
	 String getUser() {
			
			
		return this.user;
	}
	 String getpswd() {
			
			
		return this.pswd;
	}
	 
	 
	void get() {
	
	Properties propertiesobj = new Properties();
	
	InputStream input = null;
	
	try {

    String fileName = "config.properties";
    input = new FileInputStream(fileName);
    propertiesobj.load(input);

    this.url =  propertiesobj.getProperty("url");	 
    this.user = propertiesobj.getProperty("userName").toString();
    this.pswd = propertiesobj.getProperty("password");


	} catch(IOException exep) {
		
		exep.printStackTrace();
	} finally {
		if(input !=null ) {
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}}}		
	}	
}