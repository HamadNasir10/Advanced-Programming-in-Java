/**
 Name: Hamad Nasir
 Class: BSCS-6C
 CMS_ID: 120312
 
 **/



package com.Hamad.Lab7_Hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


public class CreateSession{
	private static SessionFactory sessionFactory;
    private static ServiceRegistry serviceRegistry;
    
    public static void createSessionFactory() {
	    Configuration configuration = new Configuration();
	    configuration.configure();
	    serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
	    sessionFactory = configuration.addPackage("com.Faizi.Lab7_Hibernate").addAnnotatedClass(Person.class).buildSessionFactory(serviceRegistry);

    }

    public static ServiceRegistry getServiceRegistry(){
    	return serviceRegistry;
    }
    
    public static SessionFactory getSessionFactory(){
    	return sessionFactory;
    }

}
