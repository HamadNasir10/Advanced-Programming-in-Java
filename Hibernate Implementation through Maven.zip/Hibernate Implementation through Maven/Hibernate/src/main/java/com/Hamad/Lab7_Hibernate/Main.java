/**
 Name: Hamad Nasir
 Class: BSCS-6C
 CMS_ID: 120312
 
 **/

package com.Hamad.Lab7_Hibernate;

public class Main {
	public static void main(String[]args) {
		Person person1 = new Person(1,"Zain","Murtaza","Nust", "1258");
		Person person2 = new Person(2,"Furqan","Shahid","NUST", "2479");
		Person person3 = new Person(3,"Elon","Musk","NUST", "9854");
		
		PersonBuilder handler = new PersonBuilder();
		
		handler.addPerson(person1);
		handler.addPerson(person2);
		handler.addPerson(person3);
		
		Person updated_person3 = new Person(3,"Elon","Musk","Tesla", "0743");
		
		handler.updatePerson(updated_person3);
		
		handler.getPerson(2);


		handler.deletePerson(2);
		
		handler.finalize();	

	}
}
