# AP_Lab07
Advance Programming Lab 07.

How To Run :
  After cloning the project create a database in your system. Then change the configuration files according to your database and run the project.
